import os
import json
import logging
from flask import Flask, render_template, jsonify

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/broadband')
def broadband():
    return render_template('broadband.html')

@app.route('/devices')
def devices():
    try:
        with open('data/devices.json', 'r') as f:
            devices_data = json.load(f)
        return render_template('devices.html', devices=devices_data)
    except FileNotFoundError:
        app.logger.error("devices.json file not found")
        return render_template('devices.html', devices={"smartphones": [], "tablets": [], "data_plans": []})
    except json.JSONDecodeError:
        app.logger.error("Error parsing devices.json")
        return render_template('devices.html', devices={"smartphones": [], "tablets": [], "data_plans": []})

@app.route('/governance')
def governance():
    return render_template('governance.html')

@app.route('/wifi')
def wifi():
    return render_template('wifi.html')

@app.route('/private')
def private():
    try:
        with open('data/partners.json', 'r') as f:
            partners_data = json.load(f)
        return render_template('private.html', partners=partners_data)
    except FileNotFoundError:
        app.logger.error("partners.json file not found")
        return render_template('private.html', partners=[])
    except json.JSONDecodeError:
        app.logger.error("Error parsing partners.json")
        return render_template('private.html', partners=[])

@app.route('/wifi-data')
def wifi_data():
    """API endpoint to serve Wi-Fi hotspot data for the map"""
    try:
        with open('data/wifi.json', 'r') as f:
            wifi_data = json.load(f)
        return jsonify(wifi_data)
    except FileNotFoundError:
        app.logger.error("wifi.json file not found")
        return jsonify({"hotspots": []})
    except json.JSONDecodeError:
        app.logger.error("Error parsing wifi.json")
        return jsonify({"hotspots": []})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
